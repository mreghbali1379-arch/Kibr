package app.brailleime

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.preference.PreferenceManager

/**
 * تایپ بریل با صفحه‌کلید فیزیکی، بدون عوض کردن کیبورد گوشی (سامسونگ می‌ماند).
 * سرویس کلیدهای فیزیکی را می‌شنود و حرف بریل را در کادر متنِ فعال می‌نویسد.
 *
 * کلیدها (همان افزونه‌ی pcKbBrl):
 *   F D S = نقطه‌های ۱ تا ۳،  J K L = نقطه‌های ۴ تا ۶،  A و ; = نقطه‌های ۷ و ۸
 *   (ردیف بالا هم کار می‌کند: R E W و U I O و Q و P)
 *   Insert+0 = روشن/خاموش کردن تایپ بریل
 */
class BrailleService : AccessibilityService() {

    private val prefs: SharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(this)
    }
    private val translator = BrailleTranslator()
    private val ui = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        resetState()
        return super.onUnbind(intent)
    }

    // ------------------------------------------------------------ دسترسی به کادر متن

    private class Field(val node: AccessibilityNodeInfo, val text: String, val start: Int, val end: Int)

    /** کادر متنِ ویرایش‌پذیری که الان فوکوس ورودی دارد. */
    private fun focusedNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return null
        return if (n.isEditable) n else null
    }

    private fun readField(): Field? {
        val node = focusedNode() ?: return null
        val hint = Build.VERSION.SDK_INT >= 26 && node.isShowingHintText
        val raw = if (hint) "" else node.text?.toString() ?: ""
        var s = node.textSelectionStart
        var e = node.textSelectionEnd
        if (hint || s < 0 || e < 0) {
            s = raw.length
            e = raw.length
        }
        if (s > e) {
            val t = s
            s = e
            e = t
        }
        return Field(node, raw, s.coerceIn(0, raw.length), e.coerceIn(0, raw.length))
    }

    private fun setSelection(node: AccessibilityNodeInfo, s: Int, e: Int) {
        val a = Bundle()
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, s)
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, e)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, a)
    }

    private fun setText(node: AccessibilityNodeInfo, text: String, caret: Int): Boolean {
        val a = Bundle()
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)) return false
        setSelection(node, caret, caret)
        return true
    }

    private fun insertText(t: String) {
        val f = readField() ?: return
        val newText = f.text.substring(0, f.start) + t + f.text.substring(f.end)
        if (!setText(f.node, newText, f.start + t.length)) toast(R.string.msg_insert_failed)
    }

    private fun backspace() {
        translator.reset()
        val f = readField() ?: return
        if (f.start != f.end) {
            setText(f.node, f.text.removeRange(f.start, f.end), f.start)
            return
        }
        if (f.start == 0) return
        val prev = f.text.offsetByCodePoints(f.start, -1)
        setText(f.node, f.text.removeRange(prev, f.start), prev)
    }

    private fun enter() {
        translator.reset()
        if (Build.VERSION.SDK_INT >= 30) {
            focusedNode()?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
    }

    // ------------------------------------------------------------ نوشتن و دستورها

    private fun table(): String = prefs.getString("table", BrailleTables.FA) ?: BrailleTables.FA

    /** یک سلول بریل (ماسک نقطه‌ها) را به متن تبدیل و می‌نویسد. */
    private fun onCell(mask: Int) {
        val low = mask and 0x3F
        val high = mask and 0xC0
        if (low == 0) {
            // نقطه ۷ تنها = حذف
            // نقطه ۸ تنها: در جدول فارسی = نیم‌فاصله (طبق liblouis)، در بقیه = ورود
            when (high) {
                64 -> backspace()
                128 -> if (table() == BrailleTables.FA) {
                    translator.reset()
                    insertText(BrailleTables.ZWNJ)
                } else {
                    enter()
                }
                192 -> if (table() == BrailleTables.FA) {
                    val t = translator.translate(BrailleTables.FA, mask)   // _
                    if (t.isNotEmpty()) insertText(t)
                }
            }
            return
        }
        val text = translator.translate(table(), mask)
        if (text.isNotEmpty()) insertText(text)
    }

    private fun onSpace() {
        translator.reset()
        insertText(" ")
    }

    private fun lineStart(t: String, i: Int): Int = if (i <= 0) 0 else t.lastIndexOf('\n', i - 1) + 1

    private fun lineEnd(t: String, i: Int): Int {
        val k = t.indexOf('\n', i)
        return if (k < 0) t.length else k
    }

    private fun wordLeft(t: String, from: Int): Int {
        var i = from
        while (i > 0 && t[i - 1].isWhitespace()) i--
        while (i > 0 && !t[i - 1].isWhitespace()) i--
        return i
    }

    private fun wordRight(t: String, from: Int): Int {
        var i = from
        while (i < t.length && !t[i].isWhitespace()) i++
        while (i < t.length && t[i].isWhitespace()) i++
        return i
    }

    private fun moveLine(f: Field, up: Boolean) {
        val t = f.text
        val pos = if (up) f.start else f.end
        val ls = lineStart(t, pos)
        val col = pos - ls
        val target = if (up) {
            if (ls == 0) {
                0
            } else {
                val pls = lineStart(t, ls - 1)
                pls + minOf(col, ls - 1 - pls)
            }
        } else {
            val le = lineEnd(t, pos)
            if (le >= t.length) {
                t.length
            } else {
                val nls = le + 1
                nls + minOf(col, lineEnd(t, nls) - nls)
            }
        }
        setSelection(f.node, target, target)
    }

    /** فاصله + نقطه‌ها: دستورهای حرکت مثل نمایشگر بریل (همان نگاشت افزونه). */
    private fun spaceChord(mask: Int) {
        translator.reset()
        if (mask == DOT7) { backspace(); return }
        if (mask == DOT8) { enter(); return }
        if (mask == (DOT1 or DOT4)) { cycleLanguage(); return }
        val f = readField() ?: return
        val t = f.text
        val s = f.start
        val e = f.end
        val pos: Int = when (mask) {
            DOT3 -> if (s != e) s else if (s > 0) t.offsetByCodePoints(s, -1) else 0
            DOT6 -> if (s != e) e else if (e < t.length) t.offsetByCodePoints(e, 1) else e
            DOT2 -> wordLeft(t, s)
            DOT5 -> wordRight(t, e)
            DOT1 or DOT3 -> lineStart(t, s)
            DOT4 or DOT6 -> lineEnd(t, e)
            DOT1 or DOT2 or DOT3 -> 0
            DOT4 or DOT5 or DOT6 -> t.length
            DOT1 -> { moveLine(f, true); return }
            DOT4 -> { moveLine(f, false); return }
            0x3F -> { setSelection(f.node, 0, t.length); return }
            else -> return
        }
        setSelection(f.node, pos, pos)
    }

    // ------------------------------------------------------------ تغییر زبان (جدول بریل)

    private fun enabledTables(): List<String> {
        val all = resources.getStringArray(R.array.table_values)
        val set = prefs.getStringSet("enabled_tables", null) ?: setOf(BrailleTables.FA, BrailleTables.EN)
        val list = all.filter { it in set }
        return if (list.isEmpty()) listOf(BrailleTables.FA) else list
    }

    private fun tableName(value: String): String {
        val vals = resources.getStringArray(R.array.table_values)
        val names = resources.getStringArray(R.array.table_entries)
        val i = vals.indexOf(value)
        return if (i >= 0) names[i] else value
    }

    private fun cycleLanguage() {
        val list = enabledTables()
        val i = list.indexOf(table())          // اگر فعلی در فهرست نبود: i = -1 ← اولین مورد
        val next = list[(i + 1) % list.size]
        prefs.edit().putString("table", next).apply()
        translator.reset()
        Toast.makeText(this, tableName(next), Toast.LENGTH_SHORT).show()
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------ صفحه‌کلید فیزیکی

    private val trapped = HashSet<Int>()   // keyCode کلیدهای در حال نگه داشتن
    private var physMask = 0
    private var physSpace = false
    private val flushRunnable = Runnable { flushPhysical() }

    private val modsDown = HashSet<Int>()
    private var langArmed = false
    private var insertHeld = false
    private val zeroConsumed = HashSet<Int>()

    private fun resetState() {
        ui.removeCallbacks(flushRunnable)
        trapped.clear()
        physMask = 0
        physSpace = false
        modsDown.clear()
        langArmed = false
    }

    private fun brailleActive(): Boolean = prefs.getBoolean("braille_active", false)

    private fun oneHand(): Boolean = prefs.getBoolean("physical_one_hand", false)

    private fun toggleBraille() {
        val now = !brailleActive()
        prefs.edit().putBoolean("braille_active", now).apply()
        resetState()
        translator.reset()
        toast(if (now) R.string.msg_braille_on else R.string.msg_braille_off)
    }

    private fun langShortcutHeld(): Boolean {
        val shift = KeyEvent.KEYCODE_SHIFT_LEFT in modsDown || KeyEvent.KEYCODE_SHIFT_RIGHT in modsDown
        val alt = KeyEvent.KEYCODE_ALT_LEFT in modsDown || KeyEvent.KEYCODE_ALT_RIGHT in modsDown
        val ctrl = KeyEvent.KEYCODE_CTRL_LEFT in modsDown || KeyEvent.KEYCODE_CTRL_RIGHT in modsDown
        return when (prefs.getString("lang_shortcut", "both")) {
            "alt_shift" -> shift && alt && !ctrl
            "ctrl_shift" -> shift && ctrl && !alt
            "both" -> shift && (alt != ctrl)
            else -> false
        }
    }

    /** شناسایی کلید با کد اسکن (مستقل از چیدمان فارسی/انگلیسی/فرانسوی...). */
    private fun classify(e: KeyEvent): Int? {
        var sc = e.scanCode
        if (sc !in KNOWN_SCANS) sc = KEYCODE_TO_SCAN[e.keyCode] ?: return null
        if (sc == SCAN_SPACE) return K_SPACE
        if (oneHand()) {
            return when (sc) {
                34, 35 -> K_CONFIRM
                20, 21 -> K_CANCEL
                else -> SCAN_DOT_ONE[sc]?.let { 1 shl (it - 1) }
            }
        }
        return SCAN_DOT_TWO[sc]?.let { 1 shl (it - 1) }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN

        // روشن/خاموش کردن تایپ بریل: Insert+0
        if (code == KeyEvent.KEYCODE_INSERT) {
            insertHeld = down
            return false
        }
        if (code == KeyEvent.KEYCODE_0 || code == KeyEvent.KEYCODE_NUMPAD_0) {
            if (down) {
                if (insertHeld && prefs.getBoolean("insert0_enabled", true)) {
                    if (event.repeatCount == 0) toggleBraille()
                    zeroConsumed.add(code)
                    return true
                }
            } else if (zeroConsumed.remove(code)) {
                return true
            }
        }

        // میان‌بر زبان: Alt+Shift یا Ctrl+Shift (فقط وقتی تایپ بریل روشن است)
        if (code in MOD_KEYS) {
            if (down) {
                modsDown.add(code)
                if (brailleActive() && langShortcutHeld()) langArmed = true
            } else {
                modsDown.remove(code)
                if (langArmed) {
                    langArmed = false
                    cycleLanguage()
                }
            }
            return false
        }
        if (down) langArmed = false

        if (!brailleActive()) return false
        return handleBrailleKey(event, code, down)
    }

    private fun handleBrailleKey(event: KeyEvent, code: Int, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount > 0 && trapped.contains(code)) return true
            if (event.isCtrlPressed || event.isAltPressed || event.isMetaPressed) return false
            val kind = classify(event) ?: return false
            // اگر کادر متنی فعال نیست، کلید عادی کار کند (مثلاً پیمایش صفحه)
            if (trapped.isEmpty() && focusedNode() == null) return false
            ui.removeCallbacks(flushRunnable)
            trapped.add(code)
            when (kind) {
                K_SPACE -> if (oneHand()) { flushPhysical(); onSpace() } else physSpace = true
                K_CONFIRM -> flushPhysical()
                K_CANCEL -> physMask = 0
                else -> physMask = physMask or kind
            }
            return true
        }

        if (!trapped.remove(code)) return false
        if (oneHand()) {
            val t = prefs.getInt("timeout_physical", 100)
            if (trapped.isEmpty() && physMask != 0 && t > 0) {
                ui.postDelayed(flushRunnable, t.toLong())
            }
        } else if (trapped.isEmpty()) {
            flushPhysical()
        }
        return true
    }

    private fun flushPhysical() {
        ui.removeCallbacks(flushRunnable)
        val m = physMask
        val sp = physSpace
        physMask = 0
        physSpace = false
        if (sp) {
            if (m == 0) onSpace() else spaceChord(m)
        } else if (m != 0) {
            onCell(m)
        }
    }

    companion object {
        private val MOD_KEYS = setOf(
            KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT,
            KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT,
            KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT
        )

        const val DOT1 = 1
        const val DOT2 = 2
        const val DOT3 = 4
        const val DOT4 = 8
        const val DOT5 = 16
        const val DOT6 = 32
        const val DOT7 = 64
        const val DOT8 = 128

        private const val K_SPACE = -1
        private const val K_CONFIRM = -2
        private const val K_CANCEL = -3
        private const val SCAN_SPACE = 57

        // کدهای اسکن لینوکس/اندروید برای کلیدهای QWERTY:
        // F=33 D=32 S=31 J=36 K=37 L=38 A=30 ;=39   R=19 E=18 W=17 U=22 I=23 O=24 Q=16 P=25
        // G=34 H=35 T=20 Y=21
        private val SCAN_DOT_TWO = mapOf(
            33 to 1, 32 to 2, 31 to 3, 36 to 4, 37 to 5, 38 to 6, 30 to 7, 39 to 8,
            19 to 1, 18 to 2, 17 to 3, 22 to 4, 23 to 5, 24 to 6, 16 to 7, 25 to 8
        )

        // حالت یک دست (همان نگاشت افزونه): دست چپ f d s r e w a q → ۱ تا ۸، دست راست j k l u i o ; p → ۱ تا ۸
        private val SCAN_DOT_ONE = mapOf(
            33 to 1, 32 to 2, 31 to 3, 36 to 1, 37 to 2, 38 to 3, 30 to 7, 39 to 7,
            19 to 4, 18 to 5, 17 to 6, 22 to 4, 23 to 5, 24 to 6, 16 to 8, 25 to 8
        )

        private val KNOWN_SCANS: Set<Int> =
            SCAN_DOT_TWO.keys + setOf(34, 35, 20, 21, SCAN_SPACE)

        // اگر دستگاه کد اسکن نداد، از keyCode استفاده می‌شود
        private val KEYCODE_TO_SCAN = mapOf(
            KeyEvent.KEYCODE_F to 33, KeyEvent.KEYCODE_D to 32, KeyEvent.KEYCODE_S to 31,
            KeyEvent.KEYCODE_J to 36, KeyEvent.KEYCODE_K to 37, KeyEvent.KEYCODE_L to 38,
            KeyEvent.KEYCODE_A to 30, KeyEvent.KEYCODE_SEMICOLON to 39,
            KeyEvent.KEYCODE_R to 19, KeyEvent.KEYCODE_E to 18, KeyEvent.KEYCODE_W to 17,
            KeyEvent.KEYCODE_U to 22, KeyEvent.KEYCODE_I to 23, KeyEvent.KEYCODE_O to 24,
            KeyEvent.KEYCODE_Q to 16, KeyEvent.KEYCODE_P to 25,
            KeyEvent.KEYCODE_G to 34, KeyEvent.KEYCODE_H to 35,
            KeyEvent.KEYCODE_T to 20, KeyEvent.KEYCODE_Y to 21,
            KeyEvent.KEYCODE_SPACE to SCAN_SPACE
        )
    }
}
