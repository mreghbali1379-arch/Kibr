package app.brailleime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.customview.widget.ExploreByTouchHelper

/**
 * صفحه‌کلید بریل لمسی. نقطه‌ها در یک ردیف کنار هم هستند (نه زیر هم).
 *  - حالت دو دست: چند انگشت هم‌زمان روی نقطه‌ها؛ با برداشتن همه‌ی انگشت‌ها حرف نوشته می‌شود.
 *  - حالت یک دست: نقطه‌ها یکی‌یکی انتخاب می‌شوند و با «تأیید» (یا مهلت زمانی) ارسال می‌شوند.
 *  - فاصله + نقطه‌ها = دستورهای حرکت مکان‌نما (مثل نمایشگر بریل).
 */
class BrailleKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onCell(mask: Int)
        fun onSpace()
        fun onSpaceChord(mask: Int)
        fun onBackspace()
        fun onEnter()
        fun onSwitchKeyboard()
        fun onOpenSettings()
        fun onModeChanged(mode: String)
        fun onCycleLanguage()
    }

    private enum class Type { DOT, SPACE, BACKSPACE, ENTER, SWITCH, SETTINGS, MODE, CONFIRM, CLEAR, LANG }

    private class Key(val id: Int, val type: Type, val dot: Int = 0) {
        val rect = RectF()
        var visible = false
        var pressed = false
        val bit: Int get() = if (dot > 0) 1 shl (dot - 1) else 0
    }

    var listener: Listener? = null

    var eightDot = false
        set(value) {
            if (field != value) {
                field = value
                computeKeys()
                invalidate()
                helper.invalidateRoot()
            }
        }

    /**
     * "chord" = دو دست: انگشت‌ها هم‌زمان روی نقطه‌ها
     * "slide" = یک لمس: انگشت را روی نقطه‌ها بکشید، با برداشتن انگشت حرف نوشته می‌شود
     * "sequential" = نقطه‌ها را تک‌تک انتخاب و تأیید کنید (مناسب TalkBack)
     */
    var touchMode = "slide"
        set(value) {
            if (field != value) {
                field = value
                ui.removeCallbacks(commitRunnable)
                pendingMask = 0
                chordMask = 0
                computeKeys()
                invalidate()
                helper.invalidateRoot()
            }
        }

    private val sequential: Boolean get() = touchMode == "sequential"

    /** "perkins" = ۳ ۲ ۱ ۴ ۵ ۶ (مثل کلیدهای S D F J K L)،  "natural" = ۱ ۲ ۳ ۴ ۵ ۶ */
    var dotOrder = "perkins"
        set(value) {
            if (field != value) {
                field = value
                computeKeys()
                invalidate()
                helper.invalidateRoot()
            }
        }

    var haptic = true
    var speakDots = true
    var timeoutMs = 0

    /** برچسب کوتاه و نام کامل زبان فعلی (روی کلید زبان). */
    var languageLabel = "فا"
        set(value) {
            field = value
            invalidate()
        }
    var languageName = ""
        set(value) {
            field = value
            helper.invalidateRoot()
        }

    private val ui = Handler(Looper.getMainLooper())
    private val density = resources.displayMetrics.density
    private val scaledDensity = resources.displayMetrics.scaledDensity
    private val gap = 3f * density
    private val corner = 14f * density

    private val keys = listOf(
        Key(1, Type.DOT, 1), Key(2, Type.DOT, 2), Key(3, Type.DOT, 3),
        Key(4, Type.DOT, 4), Key(5, Type.DOT, 5), Key(6, Type.DOT, 6),
        Key(7, Type.DOT, 7), Key(8, Type.DOT, 8),
        Key(10, Type.SPACE), Key(11, Type.BACKSPACE), Key(12, Type.ENTER),
        Key(13, Type.SWITCH), Key(14, Type.SETTINGS), Key(15, Type.MODE),
        Key(16, Type.CONFIRM), Key(17, Type.CLEAR), Key(18, Type.LANG)
    )

    private val pointerKeys = SparseArray<Key>()
    private var chordMask = 0
    private var spaceHeld = false
    private var pendingMask = 0

    private val bgPaint = Paint().apply { color = Color.parseColor("#15161A") }
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    private val cDot = Color.parseColor("#2B3140")
    private val cKey = Color.parseColor("#23262D")
    private val cSelected = Color.parseColor("#2F6BFF")
    private val cPressed = Color.parseColor("#5B8CFF")

    private val commitRunnable = Runnable { commitPending() }
    private val repeatRunnable = object : Runnable {
        override fun run() {
            listener?.onBackspace()
            ui.postDelayed(this, 70)
        }
    }

    // ---------------------------------------------------------------- accessibility

    private val helper = object : ExploreByTouchHelper(this@BrailleKeyboardView) {
        override fun getVirtualViewAt(x: Float, y: Float): Int =
            keyAt(x, y)?.id ?: ExploreByTouchHelper.INVALID_ID

        override fun getVisibleVirtualViews(virtualViewIds: MutableList<Int>) {
            for (k in keys) if (k.visible) virtualViewIds.add(k.id)
        }

        override fun onPopulateNodeForVirtualView(id: Int, node: AccessibilityNodeInfoCompat) {
            val k = byId(id)
            node.contentDescription = describe(k)
            node.className = "android.widget.Button"
            val r = Rect()
            k.rect.roundOut(r)
            node.setBoundsInParent(r)
            node.addAction(AccessibilityNodeInfoCompat.ACTION_CLICK)
            if (k.type == Type.DOT) {
                node.isCheckable = true
                node.isChecked = isSelected(k)
            }
        }

        override fun onPopulateEventForVirtualView(id: Int, event: android.view.accessibility.AccessibilityEvent) {
            event.contentDescription = describe(byId(id))
        }

        override fun onPerformActionForVirtualView(id: Int, action: Int, arguments: Bundle?): Boolean {
            if (action == AccessibilityNodeInfoCompat.ACTION_CLICK) {
                activate(byId(id))
                return true
            }
            return false
        }
    }

    init {
        ViewCompat.setAccessibilityDelegate(this, helper)
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    override fun dispatchHoverEvent(event: MotionEvent): Boolean =
        helper.dispatchHoverEvent(event) || super.dispatchHoverEvent(event)

    private fun describe(k: Key): String = when (k.type) {
        Type.DOT -> context.getString(R.string.key_dot, k.dot) +
            (if (isSelected(k)) ", " + context.getString(R.string.state_selected) else "")
        Type.SPACE -> context.getString(R.string.key_space)
        Type.BACKSPACE -> context.getString(R.string.key_backspace)
        Type.ENTER -> context.getString(R.string.key_enter)
        Type.SWITCH -> context.getString(R.string.key_switch)
        Type.SETTINGS -> context.getString(R.string.key_settings)
        Type.MODE -> context.getString(
            when (touchMode) {
                "chord" -> R.string.key_mode_chord
                "slide" -> R.string.key_mode_slide
                else -> R.string.key_mode_seq
            }
        )
        Type.CONFIRM -> context.getString(R.string.key_confirm)
        Type.CLEAR -> context.getString(R.string.key_clear)
        Type.LANG -> context.getString(R.string.key_language, languageName)
    }

    private fun isSelected(k: Key): Boolean =
        k.type == Type.DOT && ((pendingMask and k.bit) != 0)

    // ---------------------------------------------------------------- layout

    private fun byId(id: Int): Key = keys.first { it.id == id }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (280 * density).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeKeys()
        helper.invalidateRoot()
    }

    private fun place(id: Int, l: Float, t: Float, r: Float, b: Float) {
        val k = byId(id)
        k.rect.set(l + gap, t + gap, r - gap, b - gap)
        k.visible = true
    }

    private fun computeKeys() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        for (k in keys) k.visible = false

        // ردیف بالا: تعویض کیبورد، زبان، تنظیمات، حالت، حذف، ورود
        val topH = h * 0.18f
        val top = intArrayOf(13, 18, 14, 15, 11, 12)
        val kw = w / top.size
        top.forEachIndexed { i, id -> place(id, i * kw, 0f, (i + 1) * kw, topH) }

        // ردیف نقطه‌ها: همه کنار هم در یک ردیف
        val order = (if (dotOrder == "natural") listOf(1, 2, 3, 4, 5, 6) else listOf(3, 2, 1, 4, 5, 6))
            .toMutableList()
        if (eightDot) {
            order.add(0, 7)
            order.add(8)
        }
        val dotsH = h * 0.42f
        val dw = w / order.size
        order.forEachIndexed { i, d -> place(d, i * dw, topH, (i + 1) * dw, topH + dotsH) }

        var y = topH + dotsH
        if (sequential) {
            val ch = h * 0.14f
            place(16, 0f, y, w / 2f, y + ch)
            place(17, w / 2f, y, w, y + ch)
            y += ch
        }
        place(10, 0f, y, w, h)
    }

    private fun keyAt(x: Float, y: Float): Key? = keys.firstOrNull {
        it.visible && x >= it.rect.left - gap && x <= it.rect.right + gap &&
            y >= it.rect.top - gap && y <= it.rect.bottom + gap
    }

    // ---------------------------------------------------------------- drawing

    private fun label(k: Key): String = when (k.type) {
        Type.DOT -> k.dot.toString()
        Type.SPACE -> context.getString(R.string.key_space)
        Type.BACKSPACE -> "⌫"
        Type.ENTER -> "↵"
        Type.SWITCH -> "🌐"
        Type.SETTINGS -> "⚙"
        Type.MODE -> context.getString(
            when (touchMode) {
                "chord" -> R.string.label_chord
                "slide" -> R.string.label_slide
                else -> R.string.label_seq
            }
        )
        Type.CONFIRM -> "✓"
        Type.CLEAR -> "✗"
        Type.LANG -> languageLabel
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        for (k in keys) {
            if (!k.visible) continue
            val selected = k.type == Type.DOT &&
                (((pendingMask or chordMask) and k.bit) != 0)
            keyPaint.color = when {
                k.pressed -> cPressed
                selected -> cSelected
                k.type == Type.DOT -> cDot
                else -> cKey
            }
            canvas.drawRoundRect(k.rect, corner, corner, keyPaint)

            val size = minOf(k.rect.height() * 0.42f, 30f * scaledDensity)
            textPaint.textSize = when (k.type) {
                Type.DOT -> size * 1.2f
                Type.MODE, Type.LANG -> size * 0.75f
                else -> size
            }
            val fm = textPaint.fontMetrics
            val y = k.rect.centerY() - (fm.ascent + fm.descent) / 2f
            canvas.drawText(label(k), k.rect.centerX(), y, textPaint)
        }
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                handleDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                if (touchMode == "slide") {
                    for (i in 0 until e.pointerCount) handleMove(e.getPointerId(i), e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                handleUp(e.getPointerId(i), e.getX(i), e.getY(i), false)
            }
            MotionEvent.ACTION_CANCEL -> {
                for (i in 0 until e.pointerCount) handleUp(e.getPointerId(i), e.getX(i), e.getY(i), true)
                pointerKeys.clear()
                chordMask = 0
                spaceHeld = false
                stopRepeat()
                invalidate()
            }
        }
        return true
    }

    private fun handleDown(id: Int, x: Float, y: Float) {
        val key = keyAt(x, y) ?: return
        pointerKeys.put(id, key)
        key.pressed = true
        if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        when (key.type) {
            Type.DOT -> if (!sequential) chordMask = chordMask or key.bit
            Type.SPACE -> if (!sequential) spaceHeld = true
            Type.BACKSPACE -> {
                listener?.onBackspace()
                ui.postDelayed(repeatRunnable, 400)
            }
            else -> {}
        }
        invalidate()
    }

    /** حالت «یک لمس»: وقتی انگشت از روی یک نقطه به نقطه‌ی دیگر می‌لغزد، آن نقطه هم اضافه می‌شود. */
    private fun handleMove(id: Int, x: Float, y: Float) {
        val start = pointerKeys.get(id) ?: return
        if (start.type != Type.DOT) return
        val k = keyAt(x, y) ?: return
        if (k.type == Type.DOT && (chordMask and k.bit) == 0) {
            chordMask = chordMask or k.bit
            if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            invalidate()
        }
    }

    private fun handleUp(id: Int, x: Float, y: Float, cancelled: Boolean) {
        val key = pointerKeys.get(id) ?: return
        pointerKeys.remove(id)
        key.pressed = false
        val inside = !cancelled && keyAt(x, y) === key
        when (key.type) {
            Type.DOT, Type.SPACE ->
                if (sequential) { if (inside) activate(key) } else flushIfDone(!cancelled)
            Type.BACKSPACE -> stopRepeat()
            else -> if (inside) activate(key)
        }
        invalidate()
    }

    /** وقتی همه‌ی انگشت‌های روی نقطه‌ها/فاصله برداشته شد، حرف را می‌فرستد. */
    private fun flushIfDone(commit: Boolean) {
        for (i in 0 until pointerKeys.size()) {
            val t = pointerKeys.valueAt(i).type
            if (t == Type.DOT || t == Type.SPACE) return
        }
        val mask = chordMask
        val sp = spaceHeld
        chordMask = 0
        spaceHeld = false
        if (!commit) return
        if (sp) {
            if (mask == 0) listener?.onSpace() else listener?.onSpaceChord(mask)
        } else if (mask != 0) {
            listener?.onCell(mask)
        }
    }

    private fun stopRepeat() = ui.removeCallbacks(repeatRunnable)

    // ---------------------------------------------------------------- actions

    /** اجرای عمل یک کلید (هم برای لمس در حالت یک دست و هم برای TalkBack). */
    private fun activate(key: Key) {
        when (key.type) {
            Type.DOT ->
                if (sequential) toggleDot(key) else listener?.onCell(key.bit)
            Type.SPACE -> { commitPending(); listener?.onSpace() }
            Type.BACKSPACE -> listener?.onBackspace()
            Type.ENTER -> { commitPending(); listener?.onEnter() }
            Type.SWITCH -> listener?.onSwitchKeyboard()
            Type.SETTINGS -> listener?.onOpenSettings()
            Type.MODE -> {
                touchMode = when (touchMode) {
                    "chord" -> "slide"
                    "slide" -> "sequential"
                    else -> "chord"
                }
                listener?.onModeChanged(touchMode)
            }
            Type.CONFIRM -> commitPending()
            Type.CLEAR -> clearPending()
            Type.LANG -> listener?.onCycleLanguage()
        }
    }

    private fun toggleDot(key: Key) {
        pendingMask = pendingMask xor key.bit
        ui.removeCallbacks(commitRunnable)
        if (pendingMask != 0 && timeoutMs > 0) ui.postDelayed(commitRunnable, timeoutMs.toLong())
        if (speakDots) announceForAccessibility(describe(key))
        invalidate()
        helper.invalidateRoot()
    }

    private fun commitPending() {
        ui.removeCallbacks(commitRunnable)
        val m = pendingMask
        pendingMask = 0
        if (m != 0) listener?.onCell(m)
        invalidate()
        helper.invalidateRoot()
    }

    private fun clearPending() {
        ui.removeCallbacks(commitRunnable)
        pendingMask = 0
        invalidate()
        helper.invalidateRoot()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        ui.removeCallbacksAndMessages(null)
        pointerKeys.clear()
        chordMask = 0
        spaceHeld = false
    }
}
