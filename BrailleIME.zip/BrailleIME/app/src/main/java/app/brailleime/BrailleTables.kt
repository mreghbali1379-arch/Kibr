package app.brailleime

/**
 * جدول‌های بریل و مترجم.
 * ورودی: ماسک نقطه‌ها (نقطه ۱ = بیت ۰، نقطه ۲ = بیت ۱، ... نقطه ۸ = بیت ۷).
 * خروجی: متنی که باید در کادر نوشته شود (ممکن است خالی باشد، مثلاً برای نشانگر عدد).
 */
object BrailleTables {
    const val FA = "fa"
    const val EN = "en"
    const val ASCII = "ascii"
    const val UNICODE = "unicode"

    const val ZWNJ = "\u200C"

    /** بریل کامپیوتری (ASCII braille): اندیس = ماسک شش‌نقطه‌ای. */
    private const val ASCII_ORDER =
        " A1B'K2L@CIF/MSP\"E3H9O6R^DJG>NTQ,*5<-U8V.%[\$+X!&;:4\\0Z7(_?W]#Y)="

    /** الگوی نقطه‌ی a..j (و ارقام ۱ تا ۰). */
    val A_TO_J = intArrayOf(1, 3, 9, 25, 17, 11, 27, 19, 10, 26)

    const val NUMBER_SIGN = 60 // نقطه‌های ۳۴۵۶
    const val DOT6 = 32

    val LATIN: Map<Int, Char> = buildMap {
        for (i in 0..9) {
            put(A_TO_J[i], 'a' + i)          // a..j
            put(A_TO_J[i] or 4, 'k' + i)     // k..t  (+ نقطه ۳)
        }
        val ux = charArrayOf('u', 'v', 'x', 'y', 'z')
        for (i in 0..4) put(A_TO_J[i] or 36, ux[i]) // u v x y z (+ نقطه‌های ۳ و ۶)
        put(58, 'w')
    }

    val EN_PUNCT: Map<Int, Char> = mapOf(
        2 to ',', 6 to ';', 18 to ':', 50 to '.', 22 to '!',
        38 to '?', 4 to '\'', 36 to '-', 52 to '"'
    )

    /**
     * جدول فارسی؛ برگرفته از جدول رسمی liblouis (fa-ir-g1.utb) که NVDA هم از آن استفاده می‌کند.
     * کلید = ماسک شش‌نقطه‌ای، مقدار = نویسه.
     */
    val FA_DIRECT: Map<Int, String> = mapOf(
        1 to "\u0627",   // dots 1
        3 to "\u0628",   // dots 12
        15 to "\u067E",   // dots 1234
        30 to "\u062A",   // dots 2345
        57 to "\u062B",   // dots 1456
        26 to "\u062C",   // dots 245
        9 to "\u0686",   // dots 14
        49 to "\u062D",   // dots 156
        45 to "\u062E",   // dots 1346
        25 to "\u062F",   // dots 145
        46 to "\u0630",   // dots 2346
        23 to "\u0631",   // dots 1235
        53 to "\u0632",   // dots 1356
        44 to "\u0698",   // dots 346
        14 to "\u0633",   // dots 234
        41 to "\u0634",   // dots 146
        47 to "\u0635",   // dots 12346
        43 to "\u0636",   // dots 1246
        62 to "\u0637",   // dots 23456
        63 to "\u0638",   // dots 123456
        55 to "\u0639",   // dots 12356
        35 to "\u063A",   // dots 126
        11 to "\u0641",   // dots 124
        31 to "\u0642",   // dots 12345
        5 to "\u06A9",   // dots 13
        27 to "\u06AF",   // dots 1245
        7 to "\u0644",   // dots 123
        13 to "\u0645",   // dots 134
        29 to "\u0646",   // dots 1345
        58 to "\u0648",   // dots 2456
        19 to "\u0647",   // dots 125
        10 to "\u06CC",   // dots 24
        4 to "\u0621",   // dots 3
        28 to "\u0622",   // dots 345
        12 to "\u0623",   // dots 34
        51 to "\u0624",   // dots 1256
        61 to "\u0626",   // dots 13456
        21 to "\u0649",   // dots 135
        33 to "\u0629",   // dots 16
        2 to "\u060C",   // dots 2
        6 to "\u061B",   // dots 23
        38 to "\u061F",   // dots 236
        50 to "\u002E",   // dots 256
        18 to "\u003A",   // dots 25
        22 to "\u0021",   // dots 235
        36 to "\u002D",   // dots 36
        52 to "\u00BB",   // dots 356
        42 to "\u003C",   // dots 246
        8 to "\u0040",   // dots 4
        24 to "\u007E",  // dots 45  ~
        17 to "\u0650",  // dots 15   کسره
        37 to "\u064F",  // dots 136  ضمه
        20 to "\u064D",  // dots 35   تنوین کسره
        34 to "\u064C",  // dots 26   تنوین ضمه
        32 to "\u0651",  // dots 6    تشدید
    )

    /** نقطه‌های ۷ و ۸ هم‌زمان + الگو: حرکات و نویسه‌های هم‌الگو با نشانه‌های دیگر. */
    val FA_ALT78: Map<Int, String> = mapOf(
        2 to "\u064E",   // dots 2
        17 to "\u0650",   // dots 15
        37 to "\u064F",   // dots 136
        6 to "\u064B",   // dots 23
        20 to "\u064D",   // dots 35
        34 to "\u064C",   // dots 26
        32 to "\u0651",   // dots 6
        18 to "\u0652",   // dots 25
        12 to "\u0625",   // dots 34
        38 to "\u00AB",   // dots 236
        0 to "\u005F",    // dots 78  _
    )

    /** نقطه ۸ + الگو: نشانه‌های لاتین (طبق جدول). حروف لاتین: نقطه ۷ + الگوی حرف = کوچک، نقطه ۸ = بزرگ. */
    val FA_DOT8: Map<Int, String> = mapOf(
        12 to "\u002F",   // dots 34
        47 to "\u0026",   // dots 12346
        51 to "\u005C",   // dots 1256
        44 to "\u005E",   // dots 346
        8 to "\u0060",   // dots 4
        52 to "\u00B0",   // dots 356
    )

    const val FA_DIGITS = "\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9\u06F0"

    private fun unicode(mask: Int): String = String(Character.toChars(0x2800 + (mask and 0xFF)))

    fun asciiChar(low: Int): Char = ASCII_ORDER[low and 0x3F]

    fun unicodeCell(mask: Int): String = unicode(mask)
}

class BrailleTranslator {
    private var numberMode = false
    private var capNext = false
    private var capLock = false
    private var parenOpen = false
    private var mathPrefix = false

    fun reset() {
        numberMode = false
        capNext = false
        capLock = false
        parenOpen = false
        mathPrefix = false
    }

    fun translate(table: String, mask: Int): String {
        val low = mask and 0x3F
        val dot7 = (mask and 64) != 0
        val dot8 = (mask and 128) != 0

        if (table == BrailleTables.UNICODE) return BrailleTables.unicodeCell(mask)
        if (table == BrailleTables.FA) return persian(low, dot7, dot8, mask)
        if (dot8) return BrailleTables.unicodeCell(mask)

        return when (table) {
            BrailleTables.ASCII -> {
                val c = BrailleTables.asciiChar(low)
                when {
                    c.isLetter() -> (if (dot7) c else c.lowercaseChar()).toString()
                    dot7 -> BrailleTables.unicodeCell(mask)
                    else -> c.toString()
                }
            }
            BrailleTables.EN -> english(low, dot7, mask)
            else -> BrailleTables.unicodeCell(mask)
        }
    }

    private fun digitIndex(low: Int): Int = BrailleTables.A_TO_J.indexOf(low)

    private fun english(low: Int, dot7: Boolean, mask: Int): String {
        if (low == BrailleTables.NUMBER_SIGN) { numberMode = true; return "" }
        if (low == BrailleTables.DOT6) {
            if (capNext) capLock = true else capNext = true
            return ""
        }
        if (numberMode) {
            val i = digitIndex(low)
            if (i >= 0) return ((i + 1) % 10).toString()
        }
        BrailleTables.LATIN[low]?.let { c ->
            numberMode = false
            val up = dot7 || capNext || capLock
            capNext = false
            return (if (up) c.uppercaseChar() else c).toString()
        }
        if (low == 54) { parenOpen = !parenOpen; numberMode = false; return if (parenOpen) "(" else ")" }
        BrailleTables.EN_PUNCT[low]?.let { p ->
            if (!(numberMode && (p == '.' || p == ','))) numberMode = false
            return p.toString()
        }
        return BrailleTables.unicodeCell(mask)
    }

    private fun persian(low: Int, dot7: Boolean, dot8: Boolean, mask: Int): String {
        // نقطه‌های ۷ و ۸ با هم + الگو: حرکات (فتحه، کسره، ...) و نویسه‌های هم‌الگو
        if (dot7 && dot8) return BrailleTables.FA_ALT78[low] ?: BrailleTables.unicodeCell(mask)

        // نقطه ۷ یا ۸ + الگو
        if (dot7 || dot8) {
            if (low == 16) return "\""                                   // نقطه‌های ۵۷ / ۵۸ = گیومه‌ی انگلیسی
            BrailleTables.LATIN[low]?.let { c ->
                numberMode = false
                return (if (dot7) c.uppercaseChar() else c).toString()   // ۷ = بزرگ، ۸ = کوچک (مثل liblouis)
            }
            if (dot8) BrailleTables.FA_DOT8[low]?.let { return it }
            return BrailleTables.unicodeCell(mask)
        }

        if (low == BrailleTables.NUMBER_SIGN) { numberMode = true; return "" }
        // نشانه‌های ریاضی: نقطه‌های ۵۶ و بعد سلول بعدی (+ = × ÷ −)
        if (mathPrefix) {
            mathPrefix = false
            val m = when (low) {
                22 -> "+"
                54 -> "="
                38 -> "\u00D7"
                50 -> "\u00F7"
                36 -> "\u2212"
                else -> null
            }
            if (m != null) { numberMode = false; return m }
        }
        if (low == 48) { mathPrefix = true; return "" }
        if (numberMode) {
            val i = digitIndex(low)
            if (i >= 0) return BrailleTables.FA_DIGITS[i].toString()
            if (low == 2) return "\u066B"   // ممیز اعشار
            if (low == 4) return "\u066C"   // جداکننده‌ی هزارگان
        }
        if (low == 54) { parenOpen = !parenOpen; numberMode = false; return if (parenOpen) "(" else ")" }
        if (low == 56) { numberMode = false; return BrailleTables.ZWNJ }   // نقطه‌های ۴۵۶ = نیم‌فاصله (برای صفحه‌کلید شش‌نقطه‌ای)
        BrailleTables.FA_DIRECT[low]?.let { numberMode = false; return it }
        return BrailleTables.unicodeCell(mask)
    }
}
