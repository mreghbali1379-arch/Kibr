package app.brailleime

/**
 * جدول‌های بریل و مترجم.
 * ورودی: ماسک نقطه‌ها (نقطه ۱ = بیت ۰، نقطه ۲ = بیت ۱، ... نقطه ۸ = بیت ۷).
 * خروجی: متنی که باید در کادر نوشته شود (ممکن است خالی باشد، مثلاً برای نشانگر عدد).
 */
object BrailleTables {
    const val FA = "fa"
    const val EN = "en"
    const val ASCII = "ascii"
    const val UNICODE = "unicode"

    const val ZWNJ = "\u200C"

    /** بریل کامپیوتری (ASCII braille): اندیس = ماسک شش‌نقطه‌ای. */
    private const val ASCII_ORDER =
        " A1B'K2L@CIF/MSP\"E3H9O6R^DJG>NTQ,*5<-U8V.%[\$+X!&;:4\\0Z7(_?W]#Y)="

    /** الگوی نقطه‌ی a..j (و ارقام ۱ تا ۰). */
    val A_TO_J = intArrayOf(1, 3, 9, 25, 17, 11, 27, 19, 10, 26)

    const val NUMBER_SIGN = 60 // نقطه‌های ۳۴۵۶
    const val DOT6 = 32

    val LATIN: Map<Int, Char> = buildMap {
        for (i in 0..9) {
            put(A_TO_J[i], 'a' + i)          // a..j
            put(A_TO_J[i] or 4, 'k' + i)     // k..t  (+ نقطه ۳)
        }
        val ux = charArrayOf('u', 'v', 'x', 'y', 'z')
        for (i in 0..4) put(A_TO_J[i] or 36, ux[i]) // u v x y z (+ نقطه‌های ۳ و ۶)
        put(58, 'w')
    }

    val EN_PUNCT: Map<Int, Char> = mapOf(
        2 to ',', 6 to ';', 18 to ':', 50 to '.', 22 to '!',
        38 to '?', 4 to '\'', 36 to '-', 52 to '"'
    )

    /**
     * جدول فارسی (بر پایه‌ی بریل فارسی/عربی).
     * اگر الگوی حرفی با جدول مورد نظر شما فرق دارد، فقط همین‌جا عوض کنید.
     */
    val FA_LETTERS: Map<Int, String> = mapOf(
        1 to "ا", 28 to "آ", 3 to "ب", 15 to "پ", 30 to "ت", 57 to "ث",
        26 to "ج", 33 to "چ", 49 to "ح", 45 to "خ", 25 to "د", 46 to "ذ",
        23 to "ر", 53 to "ز", 42 to "ژ", 14 to "س", 41 to "ش", 47 to "ص",
        43 to "ض", 62 to "ط", 63 to "ظ", 55 to "ع", 35 to "غ", 11 to "ف",
        31 to "ق", 5 to "ک", 27 to "گ", 7 to "ل", 13 to "م", 29 to "ن",
        58 to "و", 19 to "ه", 61 to "ی", 4 to "ء"
    )

    val FA_PUNCT: Map<Int, String> = mapOf(
        2 to "،", 6 to "؛", 18 to ":", 50 to ".", 22 to "!", 38 to "؟",
        36 to "-", 56 to ZWNJ // نقطه‌های ۴۵۶ = نیم‌فاصله
    )

    const val FA_DIGITS = "۱۲۳۴۵۶۷۸۹۰"

    private fun unicode(mask: Int): String = String(Character.toChars(0x2800 + (mask and 0xFF)))

    fun asciiChar(low: Int): Char = ASCII_ORDER[low and 0x3F]

    fun unicodeCell(mask: Int): String = unicode(mask)
}

class BrailleTranslator {
    private var numberMode = false
    private var capNext = false
    private var capLock = false
    private var parenOpen = false

    fun reset() {
        numberMode = false
        capNext = false
        capLock = false
        parenOpen = false
    }

    fun translate(table: String, mask: Int): String {
        val low = mask and 0x3F
        val dot7 = (mask and 64) != 0
        val dot8 = (mask and 128) != 0

        if (table == BrailleTables.UNICODE || dot8) return BrailleTables.unicodeCell(mask)

        return when (table) {
            BrailleTables.ASCII -> {
                val c = BrailleTables.asciiChar(low)
                when {
                    c.isLetter() -> (if (dot7) c else c.lowercaseChar()).toString()
                    dot7 -> BrailleTables.unicodeCell(mask)
                    else -> c.toString()
                }
            }
            BrailleTables.EN -> english(low, dot7, mask)
            else -> persian(low, dot7, mask)
        }
    }

    private fun digitIndex(low: Int): Int = BrailleTables.A_TO_J.indexOf(low)

    private fun english(low: Int, dot7: Boolean, mask: Int): String {
        if (low == BrailleTables.NUMBER_SIGN) { numberMode = true; return "" }
        if (low == BrailleTables.DOT6) {
            if (capNext) capLock = true else capNext = true
            return ""
        }
        if (numberMode) {
            val i = digitIndex(low)
            if (i >= 0) return ((i + 1) % 10).toString()
        }
        BrailleTables.LATIN[low]?.let { c ->
            numberMode = false
            val up = dot7 || capNext || capLock
            capNext = false
            return (if (up) c.uppercaseChar() else c).toString()
        }
        if (low == 54) { parenOpen = !parenOpen; numberMode = false; return if (parenOpen) "(" else ")" }
        BrailleTables.EN_PUNCT[low]?.let { p ->
            if (!(numberMode && (p == '.' || p == ','))) numberMode = false
            return p.toString()
        }
        return BrailleTables.unicodeCell(mask)
    }

    private fun persian(low: Int, dot7: Boolean, mask: Int): String {
        if (dot7) return BrailleTables.unicodeCell(mask)
        if (low == BrailleTables.NUMBER_SIGN) { numberMode = true; return "" }
        if (numberMode) {
            val i = digitIndex(low)
            if (i >= 0) return BrailleTables.FA_DIGITS[i].toString()
        }
        BrailleTables.FA_LETTERS[low]?.let { numberMode = false; return it }
        if (low == 54) { parenOpen = !parenOpen; numberMode = false; return if (parenOpen) "(" else ")" }
        BrailleTables.FA_PUNCT[low]?.let { numberMode = false; return it }
        return BrailleTables.unicodeCell(mask)
    }
}
