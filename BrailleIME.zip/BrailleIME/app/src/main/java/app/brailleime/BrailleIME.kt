package app.brailleime

import android.content.Intent
import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.preference.PreferenceManager

/**
 * سرویس صفحه‌کلید (IME) بریل.
 * ورودی از دو منبع می‌آید و هر دو به همین منطق مشترک می‌رسند:
 *  ۱) صفحه‌کلید روی صفحه (BrailleKeyboardView)
 *  ۲) صفحه‌کلید فیزیکی (onKeyDown / onKeyUp) با همان کلیدهای افزونه‌ی pcKbBrl:
 *     F D S = نقطه‌های ۱ تا ۳،  J K L = نقطه‌های ۴ تا ۶،  A و ; = نقطه‌های ۷ و ۸
 *     (ردیف بالا هم کار می‌کند: R E W و U I O و Q و P)
 */
class BrailleIME : InputMethodService(), BrailleKeyboardView.Listener {

    private val prefs: SharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(this)
    }
    private val translator = BrailleTranslator()
    private val ui = Handler(Looper.getMainLooper())
    private var keyboardView: BrailleKeyboardView? = null
    private var editorInfo: EditorInfo? = null

    // ------------------------------------------------------------ چرخه‌ی عمر

    override fun onCreateInputView(): View {
        val v = BrailleKeyboardView(this)
        v.listener = this
        keyboardView = v
        applyViewPrefs()
        return v
    }

    private fun applyViewPrefs() {
        keyboardView?.let {
            it.eightDot = prefs.getBoolean("eight_dot", false)
            it.sequential = prefs.getBoolean("screen_one_hand", false)
            it.haptic = prefs.getBoolean("haptic", true)
            it.speakDots = prefs.getBoolean("speak_dots", true)
            it.timeoutMs = prefs.getInt("timeout_screen", 0)
        }
    }

    override fun onEvaluateInputViewShown(): Boolean {
        val always = runCatching { prefs.getBoolean("show_with_hw", true) }.getOrDefault(true)
        return always || super.onEvaluateInputViewShown()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        editorInfo = attribute
        translator.reset()
        resetPhysicalState()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        editorInfo = info
        applyViewPrefs()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        resetPhysicalState()
    }

    // ------------------------------------------------------------ نوشتن در کادر متن

    private fun table(): String = prefs.getString("table", BrailleTables.FA) ?: BrailleTables.FA

    /** یک سلول بریل (ماسک نقطه‌ها) را به متن تبدیل و می‌نویسد. */
    override fun onCell(mask: Int) {
        val ic = currentInputConnection ?: return
        val low = mask and 0x3F
        val high = mask and 0xC0
        if (low == 0) {
            // مثل BrailleBack: نقطه ۷ = حذف، نقطه ۸ = ورود، هر دو = بستن صفحه‌کلید
            when (high) {
                64 -> onBackspace()
                128 -> onEnter()
                192 -> requestHideSelf(0)
            }
            return
        }
        val text = translator.translate(table(), mask)
        if (text.isNotEmpty()) ic.commitText(text, 1)
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        translator.reset()
        ic.commitText(" ", 1)
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        translator.reset()
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            sendKey(KeyEvent.KEYCODE_DEL)
        }
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        translator.reset()
        val info = editorInfo
        if (info != null) {
            val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
            val noEnterAction = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noEnterAction &&
                action != EditorInfo.IME_ACTION_NONE &&
                action != EditorInfo.IME_ACTION_UNSPECIFIED
            ) {
                ic.performEditorAction(action)
                return
            }
        }
        sendKey(KeyEvent.KEYCODE_ENTER)
    }

    /** فاصله + نقطه‌ها: دستورهای حرکت مثل نمایشگر بریل (همان نگاشت افزونه). */
    override fun onSpaceChord(mask: Int) {
        val ctrl = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        translator.reset()
        when (mask) {
            DOT1 -> sendKey(KeyEvent.KEYCODE_DPAD_UP)
            DOT4 -> sendKey(KeyEvent.KEYCODE_DPAD_DOWN)
            DOT3 -> sendKey(KeyEvent.KEYCODE_DPAD_LEFT)
            DOT6 -> sendKey(KeyEvent.KEYCODE_DPAD_RIGHT)
            DOT2 -> sendKey(KeyEvent.KEYCODE_DPAD_LEFT, ctrl)
            DOT5 -> sendKey(KeyEvent.KEYCODE_DPAD_RIGHT, ctrl)
            DOT1 or DOT3 -> sendKey(KeyEvent.KEYCODE_MOVE_HOME)
            DOT4 or DOT6 -> sendKey(KeyEvent.KEYCODE_MOVE_END)
            DOT1 or DOT2 or DOT3 -> sendKey(KeyEvent.KEYCODE_MOVE_HOME, ctrl)
            DOT4 or DOT5 or DOT6 -> sendKey(KeyEvent.KEYCODE_MOVE_END, ctrl)
            DOT1 or DOT4 -> onSwitchKeyboard()
            DOT7 -> onBackspace()
            DOT8 -> onEnter()
            0x3F -> currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
        }
    }

    private fun sendKey(code: Int, meta: Int = 0) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    override fun onSwitchKeyboard() {
        if (Build.VERSION.SDK_INT >= 28 && switchToNextInputMethod(false)) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun onOpenSettings() {
        startActivity(
            Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    override fun onModeChanged(sequential: Boolean) {
        prefs.edit().putBoolean("screen_one_hand", sequential).apply()
    }

    // ------------------------------------------------------------ صفحه‌کلید فیزیکی

    private val trapped = HashSet<Int>()   // keyCode کلیدهای در حال نگه داشتن
    private var physMask = 0
    private var physSpace = false
    private val flushRunnable = Runnable { flushPhysical() }

    private fun resetPhysicalState() {
        ui.removeCallbacks(flushRunnable)
        trapped.clear()
        physMask = 0
        physSpace = false
    }

    private fun oneHand(): Boolean = prefs.getBoolean("physical_one_hand", false)

    /** شناسایی کلید با کد اسکن (مستقل از چیدمان فارسی/انگلیسی/فرانسوی...). */
    private fun classify(e: KeyEvent): Int? {
        var sc = e.scanCode
        if (sc !in KNOWN_SCANS) sc = KEYCODE_TO_SCAN[e.keyCode] ?: return null
        if (sc == SCAN_SPACE) return K_SPACE
        if (oneHand()) {
            return when (sc) {
                34, 35 -> K_CONFIRM
                20, 21 -> K_CANCEL
                else -> SCAN_DOT_ONE[sc]?.let { 1 shl (it - 1) }
            }
        }
        return SCAN_DOT_TWO[sc]?.let { 1 shl (it - 1) }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // روشن/خاموش کردن ورودی بریل: Ctrl+Alt+0 (مثل NVDA+0 در افزونه)
        if (event.repeatCount == 0 && event.isCtrlPressed && event.isAltPressed &&
            keyCode == KeyEvent.KEYCODE_0
        ) {
            val now = !prefs.getBoolean("physical_enabled", true)
            prefs.edit().putBoolean("physical_enabled", now).apply()
            resetPhysicalState()
            Toast.makeText(
                this,
                if (now) R.string.msg_physical_on else R.string.msg_physical_off,
                Toast.LENGTH_SHORT
            ).show()
            return true
        }

        if (event.repeatCount > 0 && trapped.contains(keyCode)) return true

        if (!prefs.getBoolean("physical_enabled", true) ||
            currentInputConnection == null ||
            event.isCtrlPressed || event.isAltPressed || event.isMetaPressed
        ) {
            return super.onKeyDown(keyCode, event)
        }

        val kind = classify(event) ?: return super.onKeyDown(keyCode, event)
        ui.removeCallbacks(flushRunnable)
        trapped.add(keyCode)
        when (kind) {
            K_SPACE -> if (oneHand()) { flushPhysical(); onSpace() } else physSpace = true
            K_CONFIRM -> flushPhysical()
            K_CANCEL -> physMask = 0
            else -> physMask = physMask or kind
        }
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (!trapped.remove(keyCode)) return super.onKeyUp(keyCode, event)
        if (oneHand()) {
            val t = prefs.getInt("timeout_physical", 100)
            if (trapped.isEmpty() && physMask != 0 && t > 0) {
                ui.postDelayed(flushRunnable, t.toLong())
            }
        } else if (trapped.isEmpty()) {
            flushPhysical()
        }
        return true
    }

    private fun flushPhysical() {
        ui.removeCallbacks(flushRunnable)
        val m = physMask
        val sp = physSpace
        physMask = 0
        physSpace = false
        if (sp) {
            if (m == 0) onSpace() else onSpaceChord(m)
        } else if (m != 0) {
            onCell(m)
        }
    }

    companion object {
        const val DOT1 = 1
        const val DOT2 = 2
        const val DOT3 = 4
        const val DOT4 = 8
        const val DOT5 = 16
        const val DOT6 = 32
        const val DOT7 = 64
        const val DOT8 = 128

        private const val K_SPACE = -1
        private const val K_CONFIRM = -2
        private const val K_CANCEL = -3
        private const val SCAN_SPACE = 57

        // کدهای اسکن لینوکس/اندروید برای کلیدهای QWERTY:
        // F=33 D=32 S=31 J=36 K=37 L=38 A=30 ;=39   R=19 E=18 W=17 U=22 I=23 O=24 Q=16 P=25
        // G=34 H=35 T=20 Y=21
        private val SCAN_DOT_TWO = mapOf(
            33 to 1, 32 to 2, 31 to 3, 36 to 4, 37 to 5, 38 to 6, 30 to 7, 39 to 8,
            19 to 1, 18 to 2, 17 to 3, 22 to 4, 23 to 5, 24 to 6, 16 to 7, 25 to 8
        )

        // حالت یک دست (همان نگاشت افزونه): دست چپ f d s r e w a q → ۱ تا ۸، دست راست j k l u i o ; p → ۱ تا ۸
        private val SCAN_DOT_ONE = mapOf(
            33 to 1, 32 to 2, 31 to 3, 36 to 1, 37 to 2, 38 to 3, 30 to 7, 39 to 7,
            19 to 4, 18 to 5, 17 to 6, 22 to 4, 23 to 5, 24 to 6, 16 to 8, 25 to 8
        )

        private val KNOWN_SCANS: Set<Int> =
            SCAN_DOT_TWO.keys + setOf(34, 35, 20, 21, SCAN_SPACE)

        // اگر دستگاه کد اسکن نداد، از keyCode استفاده می‌شود
        private val KEYCODE_TO_SCAN = mapOf(
            KeyEvent.KEYCODE_F to 33, KeyEvent.KEYCODE_D to 32, KeyEvent.KEYCODE_S to 31,
            KeyEvent.KEYCODE_J to 36, KeyEvent.KEYCODE_K to 37, KeyEvent.KEYCODE_L to 38,
            KeyEvent.KEYCODE_A to 30, KeyEvent.KEYCODE_SEMICOLON to 39,
            KeyEvent.KEYCODE_R to 19, KeyEvent.KEYCODE_E to 18, KeyEvent.KEYCODE_W to 17,
            KeyEvent.KEYCODE_U to 22, KeyEvent.KEYCODE_I to 23, KeyEvent.KEYCODE_O to 24,
            KeyEvent.KEYCODE_Q to 16, KeyEvent.KEYCODE_P to 25,
            KeyEvent.KEYCODE_G to 34, KeyEvent.KEYCODE_H to 35,
            KeyEvent.KEYCODE_T to 20, KeyEvent.KEYCODE_Y to 21,
            KeyEvent.KEYCODE_SPACE to SCAN_SPACE
        )
    }
}
