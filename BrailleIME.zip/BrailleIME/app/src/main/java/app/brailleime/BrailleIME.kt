package app.brailleime

import android.content.Intent
import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.preference.PreferenceManager

/**
 * صفحه‌کلید بریل لمسی (کیبوردی که از فهرست کیبوردهای گوشی انتخاب می‌شود).
 * تایپ بریل با صفحه‌کلید فیزیکی کار BrailleService است و به این کیبورد وابسته نیست.
 */
class BrailleIME : InputMethodService(), BrailleKeyboardView.Listener {

    private val prefs: SharedPreferences by lazy {
        PreferenceManager.getDefaultSharedPreferences(this)
    }
    private val translator = BrailleTranslator()
    private var keyboardView: BrailleKeyboardView? = null
    private var editorInfo: EditorInfo? = null

    // ------------------------------------------------------------ چرخه‌ی عمر

    override fun onCreateInputView(): View {
        val v = BrailleKeyboardView(this)
        v.listener = this
        keyboardView = v
        applyViewPrefs()
        return v
    }

    private fun applyViewPrefs() {
        keyboardView?.let {
            it.eightDot = prefs.getBoolean("eight_dot", false)
            it.touchMode = prefs.getString(
                "touch_mode",
                if (prefs.getBoolean("screen_one_hand", false)) "sequential" else "slide"
            ) ?: "slide"
            it.haptic = prefs.getBoolean("haptic", true)
            it.speakDots = prefs.getBoolean("speak_dots", true)
            it.timeoutMs = prefs.getInt("timeout_screen", 0)
            it.dotOrder = prefs.getString("dot_order", "perkins") ?: "perkins"
        }
        refreshLanguageUi()
    }

    override fun onEvaluateInputViewShown(): Boolean = true

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        editorInfo = attribute
        translator.reset()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        editorInfo = info
        applyViewPrefs()
    }

    // ------------------------------------------------------------ نوشتن در کادر متن

    private fun table(): String = prefs.getString("table", BrailleTables.FA) ?: BrailleTables.FA

    override fun onCell(mask: Int) {
        val ic = currentInputConnection ?: return
        val low = mask and 0x3F
        val high = mask and 0xC0
        if (low == 0) {
            // نقطه ۷ تنها = حذف. نقطه ۸ تنها: در جدول فارسی نیم‌فاصله، در بقیه ورود
            when (high) {
                64 -> onBackspace()
                128 -> if (table() == BrailleTables.FA) {
                    translator.reset()
                    ic.commitText(BrailleTables.ZWNJ, 1)
                } else {
                    onEnter()
                }
                192 -> if (table() == BrailleTables.FA) {
                    val t = translator.translate(BrailleTables.FA, mask)   // _
                    if (t.isNotEmpty()) ic.commitText(t, 1)
                } else {
                    requestHideSelf(0)
                }
            }
            return
        }
        val text = translator.translate(table(), mask)
        if (text.isNotEmpty()) ic.commitText(text, 1)
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        translator.reset()
        ic.commitText(" ", 1)
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        translator.reset()
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            sendKey(KeyEvent.KEYCODE_DEL)
        }
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        translator.reset()
        val info = editorInfo
        if (info != null) {
            val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
            val noEnterAction = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noEnterAction &&
                action != EditorInfo.IME_ACTION_NONE &&
                action != EditorInfo.IME_ACTION_UNSPECIFIED
            ) {
                ic.performEditorAction(action)
                return
            }
        }
        sendKey(KeyEvent.KEYCODE_ENTER)
    }

    /** فاصله + نقطه‌ها: دستورهای حرکت مثل نمایشگر بریل. */
    override fun onSpaceChord(mask: Int) {
        val ctrl = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        translator.reset()
        when (mask) {
            DOT1 -> sendKey(KeyEvent.KEYCODE_DPAD_UP)
            DOT4 -> sendKey(KeyEvent.KEYCODE_DPAD_DOWN)
            DOT3 -> sendKey(KeyEvent.KEYCODE_DPAD_LEFT)
            DOT6 -> sendKey(KeyEvent.KEYCODE_DPAD_RIGHT)
            DOT2 -> sendKey(KeyEvent.KEYCODE_DPAD_LEFT, ctrl)
            DOT5 -> sendKey(KeyEvent.KEYCODE_DPAD_RIGHT, ctrl)
            DOT1 or DOT3 -> sendKey(KeyEvent.KEYCODE_MOVE_HOME)
            DOT4 or DOT6 -> sendKey(KeyEvent.KEYCODE_MOVE_END)
            DOT1 or DOT2 or DOT3 -> sendKey(KeyEvent.KEYCODE_MOVE_HOME, ctrl)
            DOT4 or DOT5 or DOT6 -> sendKey(KeyEvent.KEYCODE_MOVE_END, ctrl)
            DOT1 or DOT4 -> onCycleLanguage()
            DOT7 -> onBackspace()
            DOT8 -> onEnter()
            0x3F -> currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
        }
    }

    private fun sendKey(code: Int, meta: Int = 0) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    override fun onSwitchKeyboard() {
        if (Build.VERSION.SDK_INT >= 28 && switchToNextInputMethod(false)) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun onOpenSettings() {
        startActivity(
            Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    override fun onModeChanged(mode: String) {
        prefs.edit().putString("touch_mode", mode).apply()
    }

    // ------------------------------------------------------------ تغییر زبان (جدول بریل)

    private fun enabledTables(): List<String> {
        val all = resources.getStringArray(R.array.table_values)
        val set = prefs.getStringSet("enabled_tables", null) ?: setOf(BrailleTables.FA, BrailleTables.EN)
        val list = all.filter { it in set }
        return if (list.isEmpty()) listOf(BrailleTables.FA) else list
    }

    private fun tableName(value: String): String {
        val vals = resources.getStringArray(R.array.table_values)
        val names = resources.getStringArray(R.array.table_entries)
        val i = vals.indexOf(value)
        return if (i >= 0) names[i] else value
    }

    private fun shortLabel(value: String): String = when (value) {
        BrailleTables.FA -> "فا"
        BrailleTables.EN -> "EN"
        BrailleTables.ASCII -> "CB"
        else -> "\u283F"
    }

    private fun refreshLanguageUi() {
        keyboardView?.let {
            it.languageLabel = shortLabel(table())
            it.languageName = tableName(table())
        }
    }

    override fun onCycleLanguage() {
        val list = enabledTables()
        val i = list.indexOf(table())          // اگر فعلی در فهرست نبود: i = -1 ← اولین مورد
        val next = list[(i + 1) % list.size]
        prefs.edit().putString("table", next).apply()
        translator.reset()
        refreshLanguageUi()
        Toast.makeText(this, tableName(next), Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val DOT1 = 1
        const val DOT2 = 2
        const val DOT3 = 4
        const val DOT4 = 8
        const val DOT5 = 16
        const val DOT6 = 32
        const val DOT7 = 64
        const val DOT8 = 128
    }
}
